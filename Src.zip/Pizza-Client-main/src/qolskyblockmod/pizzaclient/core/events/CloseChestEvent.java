// 
// Decompiled by Procyon v0.5.36
// 

package qolskyblockmod.pizzaclient.core.events;

import net.minecraftforge.fml.common.eventhandler.Event;

public class CloseChestEvent extends Event
{
}
