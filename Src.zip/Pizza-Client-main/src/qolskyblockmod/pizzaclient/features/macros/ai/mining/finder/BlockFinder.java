// 
// Decompiled by Procyon v0.5.36
// 

package qolskyblockmod.pizzaclient.features.macros.ai.mining.finder;

import net.minecraft.util.BlockPos;

public interface BlockFinder
{
    boolean isValid(final BlockPos p0);
}
