// 
// Decompiled by Procyon v0.5.36
// 

package qolskyblockmod.pizzaclient.util.graphics.shaders.uniform;

public interface IUniform
{
    void update();
}
