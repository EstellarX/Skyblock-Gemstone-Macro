// 
// Decompiled by Procyon v0.5.36
// 

package qolskyblockmod.pizzaclient.util.graphics;

public class ColorList
{
    public static final int BLACK = 0;
    public static final int RED = 16711680;
    public static final int GREEN = 65280;
    public static final int WHITE = 16777215;
    public static final int AQUA = 65535;
    public static final int LIME = 65280;
}
