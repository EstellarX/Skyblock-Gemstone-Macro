// 
// Decompiled by Procyon v0.5.36
// 

package qolskyblockmod.pizzaclient.util.handler;

public class TabHandler
{
}
