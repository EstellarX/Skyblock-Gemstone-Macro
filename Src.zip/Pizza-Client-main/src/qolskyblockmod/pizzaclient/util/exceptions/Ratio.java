// 
// Decompiled by Procyon v0.5.36
// 

package qolskyblockmod.pizzaclient.util.exceptions;

public class Ratio extends RuntimeException
{
    public Ratio(final String s) {
        super(s);
    }
    
    public Ratio() {
        super("Ratio");
    }
}
