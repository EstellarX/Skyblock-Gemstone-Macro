// 
// Decompiled by Procyon v0.5.36
// 

package qolskyblockmod.pizzaclient.util.rotation.fake;

import qolskyblockmod.pizzaclient.util.rotation.rotaters.IRotater;

public class FakeRotater implements IRotater
{
    @Override
    public void rotate() {
    }
    
    @Override
    public void add() {
    }
}
